#!/usr/bin/env python3
"""
Community learning: pool every user's settled trades (dummy paper, paper and live)
into one anonymous dataset and learn from it.

Run by the API server every few minutes:  python3 collective.py <DATA_DIR>
Writes <DATA_DIR>/global/collective.json with:
  - trades: compact anonymous trades (no names/emails/order ids; user = short hash)
  - indicators / model: accuracy stats and AI model trained on all trades
  - recommended: settings auto-tune derives from all trades (used as new-user defaults)
  - summary: users, trade counts, win rate, loss study
"""

from __future__ import annotations

import glob
import hashlib
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import learner  # noqa: E402
from binance_bot import DEFAULT_SETTINGS, merge_settings  # noqa: E402

MAX_TRADES = 20000
KEEP = ("mode", "kind", "symbol", "side", "result", "pnl", "pnlPct", "confidence", "openTime", "closeTime",
        "regime", "exitReason", "heldCandles", "votes", "quote")


def user_tag(user_id: str) -> str:
    return hashlib.sha256(user_id.encode()).hexdigest()[:10]


def main(data_dir: str):
    trades = []
    users = 0
    for path in glob.glob(os.path.join(data_dir, "users", "*", "bot_data.json")):
        user_id = os.path.basename(os.path.dirname(path))
        try:
            with open(path) as f:
                data = json.load(f)
        except Exception:
            continue
        own = [t for t in data.get("trades", []) if t.get("result") in ("win", "loss")]
        if own:
            users += 1
        tag = user_tag(user_id)
        for t in own:
            c = {k: t.get(k) for k in KEEP}
            c["user"] = tag
            c["mode"] = c.get("mode") or "paper"
            # direction the price actually moved while the trade was open (for indicator accuracy)
            entry, exit_ = t.get("entryPrice"), t.get("exitPrice")
            c["actual"] = 0 if not entry or not exit_ else (1 if exit_ > entry else -1 if exit_ < entry else 0)
            trades.append(c)

    trades.sort(key=lambda t: t.get("closeTime") or 0, reverse=True)
    trades = trades[:MAX_TRADES]

    learning = learner.empty_learning()
    for t in reversed(trades):  # oldest first so decay favours recent behaviour
        if t["actual"] and t.get("votes"):
            learner.record_outcome(learning, t["votes"], t["actual"])

    # what auto-tune would choose for a fresh account, learning from everybody's prediction bets
    base = merge_settings(DEFAULT_SETTINGS, {})
    tune_view = [dict(t, mode="paper") for t in trades]  # live results count as evidence too
    recommended, changes = ({}, [])
    if len(tune_view) >= 15:
        recommended, changes = learner.autotune(dict(base, tuneRisk=False), learning, tune_view, int(time.time() * 1000))

    wins = sum(1 for t in trades if t["result"] == "win")
    by_mode = {}
    for t in trades:
        key = f"{t['mode']}-{t.get('kind') or 'spot'}"
        m = by_mode.setdefault(key, {"trades": 0, "wins": 0, "pnl": 0.0})
        m["trades"] += 1
        m["wins"] += t["result"] == "win"
        m["pnl"] = round(m["pnl"] + (t.get("pnl") or 0), 4)

    out = {
        "version": 2,
        "updatedAt": int(time.time() * 1000),
        "users": users,
        "trades": trades,
        "indicators": learning["indicators"],
        "model": learning["model"],
        "recommended": recommended,
        "changes": changes,
        "summary": {
            "trades": len(trades), "wins": wins,
            "winRate": round(100 * wins / len(trades), 1) if trades else None,
            "byMode": by_mode,
            "lossStudy": learner.loss_study([dict(t, mode="paper") for t in trades[:2000]]),
        },
    }
    gdir = os.path.join(data_dir, "global")
    os.makedirs(gdir, exist_ok=True)
    tmp = os.path.join(gdir, "collective.json.tmp")
    with open(tmp, "w") as f:
        json.dump(out, f, default=float)
    os.replace(tmp, os.path.join(gdir, "collective.json"))
    print(json.dumps({"users": users, "trades": len(trades), "recommended": list(recommended)}))


if __name__ == "__main__":
    main(sys.argv[1])
